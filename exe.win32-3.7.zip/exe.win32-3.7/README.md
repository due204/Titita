

Titita pretende ser un programa sat multi-plataforma(GNU/Linux y Windows por el momento), súper sencillo orientado a los pequeños y medianos talleres de 
electrónica, con opciones básicas, bien simples, fáciles de comprender y utilizar en el día a día de las reparaciones electrónicas.

Cargamos todos los datos que nos solicita el programa, el nombre es obligatorio, los demás son opcionales. Al terminar la carga de los datos pulsamos el 
botón "Guardar", los datos se guardaran en la base de datos SQLite del programa y se nos preguntara si queremos imprimir la orden de reparación 
o no, adicionalmente también podemos ver la orden de reparación en el navegador predeterminado de nuestro sistema operativo.
Con el botón de guardar no solamente guardamos el nuevo registro sino que tambien actualizamos algun registro que ya este en nuestra base de datos.

Con el botón "Buscar" podemos hacer una búsqueda por numero de orden, apellido, numero de teléfono, tipo y marca en la base de datos del programa.

Con el botón "Borrar" borramos todos los campos del programa.

Con el botón "Configurar" podemos configurar la ruta a donde guardaremos las ordenes de reparaciones en pdf, los datos de las boletas generadas en pdf 
como el nombre de nuestro taller, dirección, teléfonos, celular y por ultimo la visualización de la orden de reparación en el navegador.

Version para windows: https://mega.nz/file/OgERmQZT#HnmojhKexUjmNtTUQcliM-MM8nHZFcEHswpOH-4vml0
