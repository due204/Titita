class Validacion:
    def vali(self, argus):
        if not argus:
            return False
        else:
            return argus
